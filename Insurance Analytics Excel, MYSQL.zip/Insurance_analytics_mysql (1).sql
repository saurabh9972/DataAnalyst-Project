Create database Insurance;
use Insurance;

              -- KPI 1:   Number of Invoice by Accnt Executive
select Account_Executive ,
       sum(case when income_class = "Cross Sell" then 1 else 0 end) as Cross_sell_Count,
       sum(case when income_class = "New" then 1 else 0 end) as New_Count,
       sum(case when income_class= "Renewal" then 1 else 0 end) as Renewal_Count,
       sum(case when income_class = " " then 1 else 0 end) as Null_invoice_Count,
       count(invoice_number) as Invoice_count
from invoice_new
group by account_executive
order by invoice_count desc;

                -- KPI 2: Yearly Meeting Count

select year(meeting_date) as Meeting_year,
	   count(*) as Meeting_count 
from meeting
group by Meeting_year;

               -- KPI 4: Stage Funnel by Revenue
select *from opportunity;

select Stage, sum(revenue_amount) as Revenue_amt
  from opportunity
  group by stage
  order by revenue_amt desc;
  
              -- KPI 5: Number of Meetings by Account Executive
  select*from meeting;
  
  select Account_Executive, count(*) as meeting_count
  from meeting
  group by Account_Executive
  order by meeting_count;
  
              -- KPI 6: Top 5 Opportunity by Revenue
  select *from Opportunity ;
  
  select opportunity_name, Sum(revenue_amount) as Revenue_amt
    from opportunity
    group by opportunity_name
    order by Revenue_amt desc
    limit 5;