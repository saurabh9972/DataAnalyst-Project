-- KPI 3: Target, Achieve, New,
	  -- placed_achievement_percentage, invoice_achievement_percentage
      
delimiter //
CREATE DEFINER=`root`@`localhost` PROCEDURE `Data_by_IncomeClass`(in IncomeClass varchar(20))
BEGIN
    declare budget_val double;
    
## Target, Invoice, Achievements for cross sell, new, renewal
  -- 1.TARGET AMOUNT                                                 (individual budget table) 
      set @Cross_sell_target = (select sum(Cross_sell_bugdet) from individual_budgets);
      set @New_Target = (select sum(new_budget) from individual_budgets);
      set @Renewal_Target = (select sum(renewal_budget) from individual_budgets); 
      
  -- 2.INVOICE AMOUNT                                                  (invoice table)
      set @invoice_val = (select sum(amount) from invoice_new
           where income_class = IncomeClass);
           
  -- 3.ACHIEVED VALUE                                                  (brokerage + fees table)
	  set @achieved_val = (
                         (select sum(amount) from brokerage
           where income_class = IncomeClass) +
                         (select sum(amount) from fees 
		    where income_class = IncomeClass)
						  );
	if incomeclass = "cross sell" then set budget_val = @Cross_sell_target;
       elseif incomeclass = "new" then set budget_val = @New_Target;
       elseif incomeclass = "renewal" then set budget_val = @Renewal_Target;
       else set budget_val = 0;
	end if;
    
  ## 4.Percentage % of placed Achievements for  cross sell, new, renewal 
        set @placed_achievement = (select concat(format((@achieved_val / budget_val) *100,2),'%'));
   ## 5.percentage % of invoice achievements for cross sell, new, renewal
         set @invoice_achievement = (select concat(format((@invoice_val / budget_val) *100,2),'%'));
select incomeclass, 
        format(budget_val,0) as target, 
        format(@invoice_val,0) as invoice,
        format(@achieved_val,2) as achieved,
        @placed_achievement as placed_achievement_percentage,
        @invoice_achievement as Invoice_achievement_percentage;
	
END//


call Data_by_IncomeClass('cross sell');

call insurance.Data_by_IncomeClass('new');

call insurance.Data_by_IncomeClass('renewal');